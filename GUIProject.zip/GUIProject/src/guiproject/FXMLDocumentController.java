/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package guiproject;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.beans.value.*;

/**
 *
 * @author mconners6052
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField AmountTextField;

    @FXML
    private Slider TipPercentSlider;

    @FXML
    private TextField TipTextField;

    @FXML
    private TextField TotalTextField;

    @FXML
    private Label label;

    @FXML
    private Label tipLabel;
    
    private double tipPercentage = 15;
    
    @FXML
    private void handleButtonAction(ActionEvent event) 
    {
        System.out.println("You clicked me!");
        label.setText("Hello World!");
    }
    
    @FXML
    private void calculateTip(ActionEvent event) 
    {
       double amount = Double.parseDouble(AmountTextField.getText());
       double tip = (tipPercentage/100) * amount;
       
       double total = tip + amount;
       TipTextField.setText(""+tip);
       TotalTextField.setText(""+total);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      TipPercentSlider.valueProperty().addListener(new ChangeListener<Number>()  
        {
            @Override
            public void changed(ObservableValue<? extends Number> ov,
                    Number old_val, Number new_val) {
            tipPercentage = new_val.intValue();
            tipLabel.setText(new_val.intValue() + "%");
        }
        });
    }    
    
}
