/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycloan;

/**
 *
 * @author mconners6052
 */
public class CarLoan 
{
    private double price, downPayment, loanTerm, salesTax, interestRate;
    
    CarLoan ()
    {
        price = 0;
        downPayment = 0;
        loanTerm = 0;
        salesTax = 0.07;
        interestRate = 0.09;
    }
    
    public void setPrice (double price)
    {
        this.price = price;
    }
    
    public void setDownPayment (double downPayment)
    {
        this.downPayment = downPayment;
    }
    
    public void setLoanTerm (double loanTerm)
    {
        this.loanTerm = loanTerm;
    }
    
    public void setSalesTax (double salesTax)
    {
        this.salesTax = salesTax;
    }
    
    public void setInterestRate (double interestRate)
    {
        this.interestRate = interestRate;
    }
    
    public double getPrice ()
    {
        return price;
    }
    
    public double getDownPayment ()
    {
        return downPayment;
    }
    
    public double getLoanTerm ()
    {
        return loanTerm;
    }
    
    public double getSalesTax ()
    {
        return salesTax;
    }
    
    public double getInterestRate ()
    {
        return interestRate;
    }
    
    public double calculateTaxedAmount (double price, double taxRate)
    {
        return price * taxRate; 
    }
    
    public double calculateCost (double price, double taxedAmount)
    {
        return price + taxedAmount;
    }
    
    public double calculateBorrowedAmount (double cost, double downPayment)
    {
        return cost - downPayment;
    }
    
    public double calculateInterestAmount (double borrowedAmount, double interestRate)
    {
        return borrowedAmount * interestRate;
    }    
}
