/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cycloan;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author mconners6052
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField dpField;

    @FXML
    private TextArea loanDisplay;

    @FXML
    private Slider ltSlider;

    @FXML
    private TextField priceField;

    @FXML
    private TextArea stirDisplay;
    
    @FXML
    private Button lrButton;
    
    public void lrButtonPressed (ActionEvent event)
    {
        displayStIr();
        displayLoanReport(); 
    }
    
    CarLoan cr = new CarLoan();
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
                ltSlider.valueProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> ov,
                Number old_val, Number new_val) {
                    
                 cr.setLoanTerm(new_val.intValue());
            }
        });
    }

    public void displayStIr ()
    {
        stirDisplay.setText("The sales tax rate is " + cr.getSalesTax() * 100 + "%.%n"
                + "The interest rate is " +cr.getInterestRate() * 100 + "%.");
    }
    
    public void displayLoanReport ()
    {
        cr.setPrice(Double.parseDouble(priceField.getText()));
        cr.setDownPayment(Double.parseDouble(dpField.getText()));
        double cost = cr.calculateTaxedAmount(cr.getPrice(), cr.getSalesTax());
        double borrowedAmount = cr.calculateBorrowedAmount(cost, cr.getDownPayment());
        double interestAmount = cr.calculateInterestAmount(borrowedAmount, cr.getInterestRate());
        
        loanDisplay.setText("Car Sticker Price: $ " + cr.getPrice() + 
                "%nYou will put down: $ " + cr.getDownPayment() +
                "%nTaxed Amount: $ " + cost +
                "%nYour cost: $ " + cr.calculateCost(cr.getPrice(), cost) +
                "%nBorrowed Amount: $ " + borrowedAmount +
                "%nInterest Amount: % " + interestAmount +
                "%n%nLoan term is " + cr.getLoanTerm() + " years.");
    }
    

    
}
